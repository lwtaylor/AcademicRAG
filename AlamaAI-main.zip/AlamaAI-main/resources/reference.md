# References

### Useful Links

- LangChain Conceptual Guide: https://python.langchain.com/v0.2/docs/concepts/#chat-models 
- OpenAI models: https://platform.openai.com/docs/models/gpt-4o 
- LangChain OpenAI Chat Models: https://python.langchain.com/v0.2/docs/integrations/chat/openai/ 

### Developer Notes
